import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { TokenStorageService } from '../services/token-storage.service';

function isJwt(token: string | null): boolean {
  if (!token) return false;
  const parts = token.split('.');
  return parts.length === 3;
}

export const authGuard: CanActivateFn = () => {
  const storage = inject(TokenStorageService);
  const router = inject(Router);

  // ✅ Force login on every browser refresh / app restart
  // sessionStorage refresh/run হলে থাকে না (new tab / refresh এ reset হতে পারে)
  // we use a one-time flag per app load
  const forced = sessionStorage.getItem('cp_force_login_done');

  if (!forced) {
    sessionStorage.setItem('cp_force_login_done', '1');

    // ✅ Clear tokens so guard will redirect to /login
    storage.clearAll();

    router.navigateByUrl('/login');
    return false;
  }

  // ✅ Normal auth behavior
  const access = storage.getAccessToken();
  const refresh = storage.getRefreshToken();

  if (isJwt(access) && Boolean(refresh)) {
    return true;
  }

  router.navigateByUrl('/login');
  return false;
};
