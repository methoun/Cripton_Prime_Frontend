export interface BreadcrumbItem {
  label: string;
  url?: string | null;
}
