import { ApplicationConfig, APP_INITIALIZER, inject } from '@angular/core';
import { provideRouter } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { routes } from './app.routes';
import { PermissionBootstrapService } from './core/auth/permission-bootstrap.service';

function initApp() {
  return async () => {
    const boot = inject(PermissionBootstrapService);
    await firstValueFrom(boot.init());
  };
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      multi: true
    }
  ]
};
