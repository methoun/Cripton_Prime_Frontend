export const STORAGE_KEYS = {
  accessToken: 'criptonprime_access_token',
  refreshToken: 'criptonprime_refresh_token',
  activeModule: 'criptonprime_active_module',
  loginTimeIso: 'criptonprime_login_time_iso'
} as const;
