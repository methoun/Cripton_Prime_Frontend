import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandlerFn,
  HttpRequest,
} from '@angular/common/http';
import { inject, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import {
  Observable,
  catchError,
  filter,
  finalize,
  switchMap,
  take,
  throwError,
  from // RxJS from যোগ করুন
} from 'rxjs';

import { AuthService } from '../services/auth.service';
import { TokenStorageService } from '../services/token-storage.service';

export function authInterceptor(
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<HttpEvent<unknown>> {
  const tokenStorage = inject(TokenStorageService);
  const auth = inject(AuthService);
  const router = inject(Router);
  const zone = inject(NgZone);

  const accessToken = tokenStorage.getAccessToken();
  let authReq = req;

  if (accessToken) {
    authReq = req.clone({
      setHeaders: { Authorization: `Bearer ${accessToken}` },
    });
  }

  return next(authReq).pipe(
    catchError((err: unknown) => {
      if (!(err instanceof HttpErrorResponse) || err.status !== 401) {
        return throwError(() => err);
      }

      if (req.url.includes('/api/auth/')) {
        zone.run(() => {
          auth.logoutClientSide();
          router.navigateByUrl('/login');
        });
        return throwError(() => err);
      }

      return handle401Error(req, next, auth, tokenStorage, router, zone);
    })
  );
}

function handle401Error(
  req: HttpRequest<any>,
  next: HttpHandlerFn,
  auth: any,
  tokenStorage: TokenStorageService,
  router: Router,
  zone: NgZone
): Observable<HttpEvent<any>> {
  
  if (auth.isRefreshing$.value) {
    return auth.refreshToken$.pipe(
      filter((token: any): token is string => token !== null),
      take(1),
      switchMap((newToken: string) => {
        // ✅ Zone.run এর ভেতরে রিকোয়েস্টটি পুনরায় পাঠান
        return from(zone.run(() => next(addTokenToRequest(req, newToken))));
      })
    );
  }

  auth.isRefreshing$.next(true);
  auth.refreshToken$.next(null);

  return auth.refresh().pipe(
    switchMap((success: boolean) => {
      if (!success) {
        return zone.run(() => {
          auth.logoutClientSide();
          router.navigateByUrl('/login');
          return throwError(() => new Error('Session Expired'));
        });
      }

      const newToken = tokenStorage.getAccessToken();
      auth.refreshToken$.next(newToken);

      // ✅ সবচাইতে গুরুত্বপূর্ণ অংশ: রিকোয়েস্টটি Zone-এর ভেতরে পাঠান
      // যাতে ডাটা আসার সাথে সাথে Angular UI আপডেট করতে পারে
      return from(zone.run(() => next(addTokenToRequest(req, newToken!))));
    }),
    catchError((refreshErr) => {
      zone.run(() => {
        auth.logoutClientSide();
        router.navigateByUrl('/login');
      });
      return throwError(() => refreshErr);
    }),
    finalize(() => {
      zone.run(() => auth.isRefreshing$.next(false));
    })
  );
}

function addTokenToRequest(request: HttpRequest<any>, token: string): HttpRequest<any> {
  return request.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
  });
}