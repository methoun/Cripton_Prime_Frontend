
export interface AdmAreaInfo {
  areaId: string;
  compId: string;
  areaName: string;
  areaNameBng?: string;
  areaAddressEng?: string;
  areaAddressBng?: string;
  shortName?: string;
  shortNameBng?: string;
  sortOrder?: number;
  isActive?: boolean;
}
