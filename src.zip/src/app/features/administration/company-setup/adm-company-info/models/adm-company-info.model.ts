
export interface AdmCompanyInfo {
  compId: string;
  compName: string;
  compNameBng?: string;
  addressEng?: string;
  addressBng?: string;
  phoneNo?: string;
  shortNameEng?: string;
  shortNameBng?: string;
  email?: string;
  mailPort?: number;
  mailPass?: string;
  mailFrom?: string;
  setupCompWise?: boolean;
  sortOrder?: number;
  isActive?: boolean;
}
