
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs';
import { AdmCompanyInfo } from '../models/adm-company-info.model';

@Injectable({ providedIn: 'root' })
export class AdmCompanyInfoService {
  private http = inject(HttpClient);
  private baseUrl = '/api/administration/company-setup/adm-company-info';

  getAll() {
    return this.http.get<any>(this.baseUrl).pipe(
      map(res => res.data ?? res.result ?? [])
    );
  }
}
